Code is copied from https://github.com/prs-eth/Marigold.
